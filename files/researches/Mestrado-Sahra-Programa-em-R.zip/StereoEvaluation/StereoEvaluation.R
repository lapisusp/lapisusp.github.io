###################
#
# Rotinas para execu��o do 
# Modelo de avalia��o da percep��o de tridimensionalidade para sistemas de realidade virtual estereosc�picos
#
# Projeto de Mestrado em Sistemas de Informa��o (PPgSI - USP)
# Sahra Karolina Gomes e Silva
# Orientadora: F�tima L. S. Nunes
#
###################

rm(list=ls())
source('permutationtest.r')


AvaliaTecnicas = function(dados, dicionario, plot=TRUE, subdir='') {

  systems = sort(unique(dicionario$System))
  qts = length(systems)
  techniques = sort(unique(dados$Technique))
  qtt = length(techniques)
  
  
  # block structure in data
  coldados = colnames(dados)
  if ('Scenario' %in% coldados) { 
    dados$chave = paste(dados$System, prettyNum(dados$Individual, width=3), 
                        dados$Scenario, sep='-')
  } else {
    dados$chave = paste(dados$System, prettyNum(dados$Individual, width=3), sep='-')
  }
  
  dicionario$chave = paste(dicionario$System, dicionario$Metrics, sep='-')
  
  MatrCompar = data.frame()
  MatrEscore = data.frame()
  
  # Vector of grades for each technique 
  TechniqueGrades = rep(0, qtt)

  for (ids in 1:qts) {
    currsys = systems[ids]
    dadoss = subset(dados, dados$System==currsys)
    dics = subset(dicionario, dicionario$System==currsys)
    
    # Identifica as metricas usadas no sistema atual
    metrics = sort(unique(dics$Metrics))
    qtm = length(metrics)
    
    NormConst = 10/((qtt-1) * qtm * qts)

    for (idm in 1:qtm) {
      currmet = metrics[idm]
      dadossm = subset(dadoss, dadoss$Metrics==currmet)
      dicsm = subset(dics, dics$Metrics==currmet)
      
      if (plot==TRUE) {
        plotfile = paste(subdir, 'Boxplot-', currsys, '-', currmet, '.png', sep='')
        png(filename=plotfile, width=700, height=400, pointsize=14)
        boxplot(dadossm$Value~dadossm$Technique, outline=FALSE, xlab = 'Technique', ylab=currmet,
                main=paste(currsys, ': ', currmet, sep=''))
        dev.off()
      }
      
      for (idt1 in 1:(qtt-1)) {
        vt1 = subset(dadossm, dadossm$Technique==techniques[idt1])
        for (idt2 in (idt1+1):qtt) {
          vt2 = subset(dadossm, dadossm$Technique==techniques[idt2])
          
          # Identify configurations in common
          chave = sort(intersect(vt1$chave, vt2$chave))
          idxmatch1 = match(chave, vt1$chave)
          idxmatch2 = match(chave, vt2$chave)
          
          idxindiv = vt1$Individual[idxmatch1]
          value1 = vt1$Value*dicsm$Sign
          value2 = vt2$Value*dicsm$Sign
          
          # elimina outliers das diferencas
          bbsc = boxplot(value1-value2, outline=TRUE, range = 3, plot=FALSE)
          idxvalsc = setdiff(1:length(value1), bbsc$out)
          
          resultsc = BlockPermTest(idxindiv[idxvalsc], x=value1[idxvalsc], y=value2[idxvalsc], 
                                   B=10000, alternative='two.sided', paired=TRUE)
          
          if (resultsc$p.value<=0.1) {
            idxgr = ifelse(mean(value1[idxvalsc])>=mean(value2[idxvalsc]), idt1, idt2)
          } else {
            idxgr = c(idt1, idt2)
          }
          
          TechniqueGrades[idxgr] = TechniqueGrades[idxgr] + NormConst 
          
        }  # for (idt2 in (idt1+1):qtt)
      }  # for (idt1 in 1:(qtt-1))
    }  # for (idm in 1:qtm)
    
  }  # for (ids in 1:qts)
  
  return(TechniqueGrades)
}

subdir = 'io/'

subdic = read.table(paste(subdir, 'subjective_dictionnaire.txt', sep=''), header=TRUE, sep='\t', stringsAsFactors=FALSE)
subdata = read.table(paste(subdir, 'subjective_data.txt', sep=''), header=TRUE, sep='\t', stringsAsFactors=FALSE)

SubGrades = AvaliaTecnicas(dados=subdata, dicionario=subdic, plot=TRUE, subdir=subdir)

objdic = read.table(paste(subdir, 'objective_dictionnaire.txt', sep=''), header=TRUE, sep='\t', stringsAsFactors=FALSE)
objdata = read.table(paste(subdir, 'objective_data.txt', sep=''), header=TRUE, sep='\t', stringsAsFactors=FALSE)

ObjGrades = AvaliaTecnicas(dados=objdata, dicionario=objdic, plot=TRUE, subdir=subdir)

techniques = sort(unique(objdata$Technique))
Results = data.frame(technique=techniques, ObjGrade=ObjGrades, SubGrade=SubGrades)
write.table(Results, paste(subdir, 'grades.txt', sep=''), col.names=TRUE, row.names=FALSE, sep='\t')

