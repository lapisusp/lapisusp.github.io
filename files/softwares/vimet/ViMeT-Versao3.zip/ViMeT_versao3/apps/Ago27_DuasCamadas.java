import vimet.*;
import java.awt.Container;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsDevice;
import javax.media.j3d.*;
import javax.swing.JFrame;
import vimet.object.Object3D;
import wizard.FunctionsClass;
import util.ObjectTypeEnum;
import Collision.*;
import deformation.*;
import util.FileTypeEnum;
import javax.vecmath.*;
import deformationNew.DeformacaoNova;
import vimet.loaders.MfLoader;
public class Ago27_DuasCamadas extends Environment{
//atributos 
// - Lista de objetos no universo
private Object3D organs[];
private Object3D instrument;
private static Keyboard keyboard = null;
public Ago27_DuasCamadas(Canvas3D c) {
	super(c, false);
try {
Transform3D transform;
//Instanciacao dos atributos
// - Instanciacao dos objetos
organs = new Object3D[1];
organs [0] = FunctionsClass.loadObject("./objects/organs/mama2537.off", ObjectTypeEnum.ORGAN, FileTypeEnum.MF );
transform = new Transform3D();
transform.setScale(new Vector3d(0.013, 0.013, 0.013)); 
transform.setTranslation(new Vector3d(0.0, 0.0, 0.0)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
organs [0].setTransformGroup(new TransformGroup(transform));
instrument = FunctionsClass.loadObject("./objects/instruments/seringa.obj", ObjectTypeEnum.INSTRUMENT, FileTypeEnum.OBJ );
transform = new Transform3D();
transform.setScale(new Vector3d(0.44, 0.44, 0.44)); 
transform.setTranslation(new Vector3d(-0.6, 0.0, 0.0)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
instrument.setTransformGroup(new TransformGroup(transform));
// - Instanciacao da deteccao de colisao
CollisionJava cd= new CollisionJava(organs[0].getShape3d());
cd.setSchedulingBounds(organs[0].getShape3d().getBounds());
organs [0].getShape3d().setCollidable(false);
// - Instanciacao da deformacao
		Parameters p = new Parameters();
float forca =2.333f;
MfLoader mFLoader = (MfLoader)organs[0].loaderObject;
mFLoader.setShape(organs[0].getShape3d());
mFLoader.inicializaCelulasVertices();
DeformacaoNova novaDeformacao = new DeformacaoNova((MfLoader)organs[0].loaderObject,forca);
float d[] = {0.01f};
float E[] = {0.23f};
float T[] = {0.01f};
cd.setParametros(d, T, E);
cd.setNovaDeformacao(novaDeformacao);
cd.setForcaSegundaCamada(forca);
novaDeformacao.nome="mama orgao";
cd.setObjetoInterseccao(organs);
cd.setAplicacao(this);
BranchGroup bgTemp = new BranchGroup();
		bgTemp.addChild(cd);
bgTemp.setCapability(BranchGroup.ALLOW_DETACH);
 cd.setBranchColisao(bgTemp);
		super.myLocale.addBranchGraph(bgTemp);
//Adicao dos objetos no universo
this.add(organs[0]);
this.add(instrument);
mFLoader.calculaAreasAV();
TMouse mouse = new TMouse( instrument.getTransformGroup(), super.myLocale);
 } catch (Exception e) {
e.printStackTrace();
}
}
	public static void main (String arg[]){
GraphicsConfigTemplate3D g3d = new GraphicsConfigTemplate3D();
GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
GraphicsConfiguration gcn = defaultScreen.getBestConfiguration(g3d);
Canvas3D c = new Canvas3D(gcn);
		Ago27_DuasCamadas n = new Ago27_DuasCamadas(c);
JFrame frm = new JFrame("Ago27_DuasCamadas");
Container ct = frm.getContentPane();
c.addKeyListener(keyboard);
ct.add(c);
frm.setSize(1000,800);
frm.setVisible(true);
frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}
