import vimet.*;
import java.awt.Container;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsDevice;
import javax.media.j3d.*;
import javax.swing.JFrame;
import vimet.object.Object3D;
import wizard.Wizard;
import util.ObjectTypeEnum;
import util.FileTypeEnum;
import javax.vecmath.*;
public class Teste3 extends Environment{
//atributos 
// - Lista de objetos no universo
private Object3D organs[];
private Object3D instrument;
private static Keyboard keyboard = null;
public Teste3(Canvas3D c) {
	super(c, false, " Clara ", " Direcional Refletora ");
try {
Transform3D transform;
//Instanciacao dos atributos
// - Instanciacao dos objetos
organs = new Object3D[3];
organs [0] = Wizard.loadObject(".\\objects\\organs\\mama.obj", ObjectTypeEnum.ORGAN, FileTypeEnum.OBJ );
organs [0].setApplyIlumination(true);
transform = new Transform3D();
transform.setScale(new Vector3d(0.3, 0.3, 0.3)); 
transform.setTranslation(new Vector3d(0.0, 0.0, 0.0)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
organs [0].setTransformGroup(new TransformGroup(transform));
organs [1] = Wizard.loadObject("C:\\Users\\rosy\\Documents\\Desenvolvimento\\ViMeT_2.0\\ViMeT-2.0.2\\objects\\organs\\mama.obj", ObjectTypeEnum.INTERNAL, FileTypeEnum.OBJ );
transform = new Transform3D();
transform.setScale(new Vector3d(0.3, 0.3, 0.3)); 
transform.setTranslation(new Vector3d(0.9, 0.0, 0.0)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
organs [1].setTransformGroup(new TransformGroup(transform));
organs [2] = Wizard.loadObject("C:\\Users\\rosy\\Documents\\Desenvolvimento\\ViMeT_2.0\\ViMeT-2.0.2\\objects\\organs\\mama.obj", ObjectTypeEnum.INTERNAL, FileTypeEnum.OBJ );
transform = new Transform3D();
transform.setScale(new Vector3d(0.3, 0.3, 0.3)); 
transform.setTranslation(new Vector3d(0.1, 0.0, 0.0)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
organs [2].setTransformGroup(new TransformGroup(transform));
instrument = Wizard.loadObject(".\\objects\\instruments\\seringa.obj", ObjectTypeEnum.INSTRUMENT, FileTypeEnum.OBJ );
transform = new Transform3D();
transform.setScale(new Vector3d(0.3, 0.3, 0.3)); 
transform.setTranslation(new Vector3d(-0.3, 0.0, 0.6)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
instrument.setTransformGroup(new TransformGroup(transform));
//Adicao dos objetos no universo
this.add(organs[0]);
this.add(organs[1]);
this.add(organs[2]);
this.add(instrument);
TMouse mouse = new TMouse( instrument.getTransformGroupMotion(), super.myLocale);
 } catch (Exception e) {
e.printStackTrace();
}
}
	public static void main (String arg[]){
GraphicsConfigTemplate3D g3d = new GraphicsConfigTemplate3D();
GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
GraphicsConfiguration gcn = defaultScreen.getBestConfiguration(g3d);
Canvas3D c = new Canvas3D(gcn);
		Teste3 n = new Teste3(c);
JFrame frm = new JFrame("Teste3");
Container ct = frm.getContentPane();
c.addKeyListener(keyboard);
ct.add(c);
frm.setSize(1000,800);
frm.setVisible(true);
frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}
