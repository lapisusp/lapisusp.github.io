import vimet.*;
import java.awt.Container;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsDevice;
import javax.media.j3d.*;
import javax.swing.JFrame;
import vimet.object.Object3D;
import wizard.FunctionsClass;
import util.ObjectTypeEnum;
import Collision.*;
import deformation.*;
import util.FileTypeEnum;
import javax.vecmath.*;
public class Jun13_3 extends Environment{
//atributos 
// - Lista de objetos no universo
private Object3D organs[];
private Object3D instrument;
private static Keyboard keyboard = null;
public Jun13_3(Canvas3D c) {
	super(c, false, " Clara ", " Ambiente ");
try {
Transform3D transform;
//Instanciacao dos atributos
// - Instanciacao dos objetos
organs = new Object3D[1];
organs [0] = FunctionsClass.loadObject("./objects/organs/mama.obj", ObjectTypeEnum.ORGAN, FileTypeEnum.OBJ );
organs [0].setApplyIlumination(true);
transform = new Transform3D();
transform.setScale(new Vector3d(1.0, 1.0, 1.0)); 
transform.setTranslation(new Vector3d(0.0, 0.0, 0.0)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
organs [0].setTransformGroup(new TransformGroup(transform));
organs [0].setTransformGroup(new TransformGroup(transform));
instrument = FunctionsClass.loadObject("./objects/instruments/seringa.obj", ObjectTypeEnum.INSTRUMENT, FileTypeEnum.OBJ );
transform = new Transform3D();
transform.setScale(new Vector3d(1.0, 1.0, 1.0)); 
transform.setTranslation(new Vector3d(0.0, 0.0, 0.0)); 
transform.setRotation(new AxisAngle4d(0.0, 0.0, 0.0, 0.0)); 
instrument.setTransformGroup(new TransformGroup(transform));
		BranchGroup bgTemp = new BranchGroup();
		super.myLocale.addBranchGraph(bgTemp);
//Adicao dos objetos no universo
this.add(organs[0]);
this.add(instrument);
TMouse mouse = new TMouse( instrument.getTransformGroup(), super.myLocale);
 } catch (Exception e) {
e.printStackTrace();
}
}
	public static void main (String arg[]){
GraphicsConfigTemplate3D g3d = new GraphicsConfigTemplate3D();
GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
GraphicsConfiguration gcn = defaultScreen.getBestConfiguration(g3d);
Canvas3D c = new Canvas3D(gcn);
		Jun13_3 n = new Jun13_3(c);
JFrame frm = new JFrame("Jun13_3");
Container ct = frm.getContentPane();
c.addKeyListener(keyboard);
ct.add(c);
frm.setSize(1000,800);
frm.setVisible(true);
frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}
